import type { Plugin } from 'vue';
/**
 * Vue plugin that gives the installing app its own cache bundle. Takes the app alone: Vue calls
 * `install(app, ...options)`, so `{ install: provideSwrvCache }` would read plugin options as
 * `overrides`.
 */
export declare const swrvCachePlugin: Plugin;
export default swrvCachePlugin;
