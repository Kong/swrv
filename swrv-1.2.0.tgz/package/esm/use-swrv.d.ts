import type { App, InjectionKey } from 'vue';
import SWRVCache from './cache';
import { IConfig, IKey, IResponse, fetcherFn, SwrvCacheBundle } from './types';
/**
 * Symbol.for, so that two copies of this package in one dependency graph compute the same key
 * and resolve each other's provide. Mismatched keys fail silently, as stale data. The version
 * suffix keeps incompatible majors from resolving each other's bundles.
 */
export declare const swrvCacheInjectionKey: InjectionKey<SwrvCacheBundle>;
/** The bundle `provideSwrvCache` gave this app, if any. */
export declare function getSwrvCache(app: App): SwrvCacheBundle | undefined;
/**
 * Gives `app` its own caches. Any cache omitted from `overrides` gets a fresh instance.
 *
 * Idempotent per app, so a host app and a test harness can both call it. `overrides` replaces a
 * cache implementation and only applies to the first call; to seed entries into a bundle that is
 * already provided, write to `getSwrvCache(app)`.
 *
 * @throws if `overrides` is non-empty and a bundle is already provided on this app.
 */
export declare function provideSwrvCache(app: App, overrides?: Partial<SwrvCacheBundle>): SwrvCacheBundle;
/**
 * Main mutation function for receiving data from promises to change state and
 * set data cache. To write into an app's provided bundle, pass its caches: inject the bundle in
 * setup(), where injection is legal, and use it from the handler or callback that mutates.
 */
declare const mutate: <Data>(key: string, res: Data | Promise<Data>, cache?: SWRVCache<any>, ttl?: number, refsCache?: SWRVCache<any>) => Promise<{
    data: any;
    error: any;
    isValidating: any;
}>;
declare function useSWRV<Data = any, Error = any>(key: IKey): IResponse<Data, Error>;
declare function useSWRV<Data = any, Error = any>(key: IKey, fn: fetcherFn<Data> | undefined | null, config?: IConfig): IResponse<Data, Error>;
export { mutate };
export default useSWRV;
